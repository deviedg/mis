async function residents() {
    const response = await fetch ("http:localhost:8080/residents")
    const jsonData = await response.json();
    document.getElementById('residents').innerHTML = jsonData.resident
}

async function incidents() {
    const response = await fetch ("http:localhost:8080/incidents")
    const jsonData = await response.json();
    document.getElementById('incidents').innerHTML = jsonData.incidents
}

async function staff() {
    const response = await fetch ("http:localhost:8080/staff")
    const jsonData = await response.json();
    document.getElementById('staff').innerHTML = jsonData.staff
}

async function visitors() {
    const response = await fetch ("http:localhost:8080/visitors")
    const jsonData = await response.json();
    document.getElementById('visitors').innerHTML = jsonData. visitors
}


function getDashboardInformation(){
    residents()
};
