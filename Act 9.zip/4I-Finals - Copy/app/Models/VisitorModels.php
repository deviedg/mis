class VisitorModel extends Model{
    protected $table ='visitor';

    protected $primary key ='id';

    protected $array ='array';

}