<?php

namespace App\Controllers;

class UserController extends BaseController
{
    public function index()
    {
        $data["pageTitle"] = "Barangay MIS";
        return view('dashboard/home', $data);
    }

    public function residents(){
        $data['pageTitle'] = 'Residents';
        return view('dashboard/residents',$data);
    }

    public function staff(){
        $data['pageTitle'] = 'Staff';
        return view('dashboard/staff',$data);
    }

    public function incident(){
        $data['pageTitle'] = 'Incident';
        return view('dashboard/incident',$data);
    }

    public function map(){
        $data['pageTitle'] = 'Map';
        return view('dashboard/Map',$data);
    }
}
