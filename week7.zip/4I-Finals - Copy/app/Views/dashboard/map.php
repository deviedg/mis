<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>
    <Map></Map>

    <!DOCTYPE html>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30916.092194086857!2d120.9618487011351!3d14.397650576423276!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397d3d222b1fddf%3A0xe745385189b612e4!2sBarangay%20Molino%20III%20City%20Of%20Bacoor!5e0!3m2!1sen!2sph!4v1685161001757!5m2!1sen!2sph" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>


<?= $this->endSection(); ?>